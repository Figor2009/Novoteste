/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Rocket, Shield, Zap, Play, RotateCcw, Trophy, Heart, Target } from 'lucide-react';

// --- Constants ---
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const PLAYER_SIZE = 30;
const HITBOX_RADIUS = 4;
const ENEMY_SIZE = 40;
const BOSS_SIZE = 100;
const BULLET_SIZE = 4;
const ENEMY_BULLET_SIZE = 6;
const BULLET_SPEED = 12;
const ENEMY_BULLET_SPEED = 5;
const BOSS_HEALTH_MAX = 7000;

// --- Types ---
interface Entity {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface Bullet extends Entity {
  active: boolean;
  vx?: number;
  vy?: number;
}

interface Enemy extends Entity {
  health: number;
  maxHealth: number;
  type: 'normal' | 'boss';
  active: boolean;
  phase: number;
  timer: number;
}

interface Particle extends Entity {
  vx: number;
  vy: number;
  life: number;
  color: string;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameover'>('menu');
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(100);
  const [highScore, setHighScore] = useState(0);
  const [defeatedCount, setDefeatedCount] = useState(0);
  const [bossHealth, setBossHealth] = useState(0);

  // Game Refs
  const playerRef = useRef<Entity>({
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT - 100,
    width: PLAYER_SIZE,
    height: PLAYER_SIZE,
  });
  const mouseRef = useRef({ x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT - 100 });
  const bulletsRef = useRef<Bullet[]>([]);
  const enemyBulletsRef = useRef<Bullet[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const requestRef = useRef<number>(null);
  const frameCountRef = useRef(0);

  // --- Input Handling ---
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const scaleX = CANVAS_WIDTH / rect.width;
        const scaleY = CANVAS_HEIGHT / rect.height;
        mouseRef.current = {
          x: (e.clientX - rect.left) * scaleX,
          y: (e.clientY - rect.top) * scaleY,
        };
      }
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // --- Game Loop ---
  const update = () => {
    if (gameState !== 'playing') return;
    frameCountRef.current++;

    // 1. Move Player (Mouse Follow - More Precise)
    const p = playerRef.current;
    p.x += (mouseRef.current.x - p.x) * 0.5;
    p.y += (mouseRef.current.y - p.y) * 0.5;

    // Clamp player
    p.x = Math.max(p.width / 2, Math.min(CANVAS_WIDTH - p.width / 2, p.x));
    p.y = Math.max(p.height / 2, Math.min(CANVAS_HEIGHT - p.height / 2, p.y));

    // 2. Auto-Shoot (Player)
    if (frameCountRef.current % 5 === 0) {
      bulletsRef.current.push({
        x: p.x - BULLET_SIZE / 2,
        y: p.y - p.height / 2,
        width: BULLET_SIZE,
        height: BULLET_SIZE * 3,
        active: true,
      });
    }

    // 3. Move Player Bullets
    bulletsRef.current.forEach((b) => {
      b.y -= BULLET_SPEED;
      if (b.y < -b.height) b.active = false;
    });
    bulletsRef.current = bulletsRef.current.filter((b) => b.active);

    // 4. Spawn/Update Singular Enemy
    if (enemiesRef.current.length === 0) {
      const isBoss = defeatedCount >= 3;
      const newEnemy: Enemy = {
        x: CANVAS_WIDTH / 2,
        y: -100,
        width: isBoss ? BOSS_SIZE : ENEMY_SIZE,
        height: isBoss ? BOSS_SIZE : ENEMY_SIZE,
        health: isBoss ? BOSS_HEALTH_MAX : 500,
        maxHealth: isBoss ? BOSS_HEALTH_MAX : 500,
        type: isBoss ? 'boss' : 'normal',
        active: true,
        phase: 0,
        timer: 0,
      };
      enemiesRef.current.push(newEnemy);
      if (isBoss) setBossHealth(BOSS_HEALTH_MAX);
    }

    enemiesRef.current.forEach((e) => {
      e.timer++;
      // Entry movement
      if (e.y < 100) {
        e.y += 2;
      } else {
        // Hover movement
        e.x = CANVAS_WIDTH / 2 + Math.sin(e.timer * 0.02) * (e.type === 'boss' ? 200 : 100);
      }

      // Enemy Shooting Patterns
      if (e.type === 'normal') {
        if (e.timer % 15 === 0) {
          // Aimed shot
          const angle = Math.atan2(p.y - e.y, p.x - e.x);
          enemyBulletsRef.current.push({
            x: e.x,
            y: e.y,
            width: ENEMY_BULLET_SIZE,
            height: ENEMY_BULLET_SIZE,
            vx: Math.cos(angle) * ENEMY_BULLET_SPEED,
            vy: Math.sin(angle) * ENEMY_BULLET_SPEED,
            active: true,
          });
        }
        if (e.timer % 40 === 0) {
          // Circular burst
          for (let i = 0; i < 12; i++) {
            const angle = (i / 12) * Math.PI * 2;
            enemyBulletsRef.current.push({
              x: e.x,
              y: e.y,
              width: ENEMY_BULLET_SIZE,
              height: ENEMY_BULLET_SIZE,
              vx: Math.cos(angle) * ENEMY_BULLET_SPEED * 0.8,
              vy: Math.sin(angle) * ENEMY_BULLET_SPEED * 0.8,
              active: true,
            });
          }
        }
      } else {
        // BOSS PATTERNS
        setBossHealth(e.health);
        
        // Pattern 1: Spiral (Faster)
        if (e.timer % 1 === 0) {
          const angle = e.timer * 0.15;
          enemyBulletsRef.current.push({
            x: e.x,
            y: e.y,
            width: ENEMY_BULLET_SIZE,
            height: ENEMY_BULLET_SIZE,
            vx: Math.cos(angle) * ENEMY_BULLET_SPEED,
            vy: Math.sin(angle) * ENEMY_BULLET_SPEED,
            active: true,
          });
          enemyBulletsRef.current.push({
            x: e.x,
            y: e.y,
            width: ENEMY_BULLET_SIZE,
            height: ENEMY_BULLET_SIZE,
            vx: Math.cos(angle + Math.PI) * ENEMY_BULLET_SPEED,
            vy: Math.sin(angle + Math.PI) * ENEMY_BULLET_SPEED,
            active: true,
          });
        }

        // Pattern 2: Rain (Denser)
        if (e.timer % 6 === 0) {
          enemyBulletsRef.current.push({
            x: Math.random() * CANVAS_WIDTH,
            y: 0,
            width: ENEMY_BULLET_SIZE,
            height: ENEMY_BULLET_SIZE,
            vx: 0,
            vy: ENEMY_BULLET_SPEED * 1.8,
            active: true,
          });
        }

        // Pattern 3: Targeted Burst (More bullets)
        if (e.timer % 80 === 0) {
          for (let i = -3; i <= 3; i++) {
            const angle = Math.atan2(p.y - e.y, p.x - e.x) + i * 0.15;
            enemyBulletsRef.current.push({
              x: e.x,
              y: e.y,
              width: ENEMY_BULLET_SIZE * 1.5,
              height: ENEMY_BULLET_SIZE * 1.5,
              vx: Math.cos(angle) * ENEMY_BULLET_SPEED * 1.4,
              vy: Math.sin(angle) * ENEMY_BULLET_SPEED * 1.4,
              active: true,
            });
          }
        }
      }
    });

    // 5. Move Enemy Bullets
    enemyBulletsRef.current.forEach((b) => {
      b.x += b.vx || 0;
      b.y += b.vy || 0;
      if (b.y > CANVAS_HEIGHT || b.y < -100 || b.x > CANVAS_WIDTH || b.x < 0) b.active = false;
    });
    enemyBulletsRef.current = enemyBulletsRef.current.filter((b) => b.active);

    // 6. Collision Detection
    // Enemy Bullets vs Player (Circular Hitbox)
    enemyBulletsRef.current.forEach((b) => {
      if (!b.active) return;
      const dx = b.x - p.x;
      const dy = b.y - p.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      if (distance < HITBOX_RADIUS + b.width / 2) {
        b.active = false;
        setHealth((prev) => Math.max(0, prev - 10));
        createExplosion(p.x, p.y, '#ffffff');
      }
    });

    // Player Bullets vs Enemy
    enemiesRef.current.forEach((e) => {
      bulletsRef.current.forEach((b) => {
        if (
          b.active &&
          b.x < e.x + e.width / 2 &&
          b.x + b.width > e.x - e.width / 2 &&
          b.y < e.y + e.height / 2 &&
          b.y + b.height > e.y - e.height / 2
        ) {
          b.active = false;
          e.health -= 10;
          if (e.health <= 0) {
            e.active = false;
            createExplosion(e.x, e.y, e.type === 'boss' ? '#f59e0b' : '#ef4444');
            setScore((prev) => prev + (e.type === 'boss' ? 5000 : 1000));
            setDefeatedCount((prev) => prev + 1);
            if (e.type === 'boss') {
              setDefeatedCount(0); // Reset for next loop or win condition
            }
          }
        }
      });
    });

    enemiesRef.current = enemiesRef.current.filter((e) => e.active);

    // 7. Update Particles
    particlesRef.current.forEach((part) => {
      part.x += part.vx;
      part.y += part.vy;
      part.life -= 0.02;
    });
    particlesRef.current = particlesRef.current.filter((part) => part.life > 0);

    // 8. Check Game Over
    if (health <= 0) {
      setGameState('gameover');
    }
  };

  const createExplosion = (x: number, y: number, color: string) => {
    for (let i = 0; i < 15; i++) {
      particlesRef.current.push({
        x,
        y,
        width: 3,
        height: 3,
        vx: (Math.random() - 0.5) * 8,
        vy: (Math.random() - 0.5) * 8,
        life: 1,
        color,
      });
    }
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.fillStyle = '#050505';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw Stars
    ctx.fillStyle = '#ffffff';
    for (let i = 0; i < 80; i++) {
      const x = (Math.sin(i * 123.45 + frameCountRef.current * 0.001) * 0.5 + 0.5) * CANVAS_WIDTH;
      const y = ((Math.cos(i * 678.9) * 0.5 + 0.5) * CANVAS_HEIGHT + frameCountRef.current * (i % 5 + 1)) % CANVAS_HEIGHT;
      const size = Math.random() * 2;
      ctx.globalAlpha = 0.2 + Math.random() * 0.5;
      ctx.fillRect(x, y, size, size);
    }
    ctx.globalAlpha = 1.0;

    if (gameState === 'playing' || gameState === 'gameover') {
      // Draw Player
      const p = playerRef.current;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.moveTo(0, -p.height / 2);
      ctx.lineTo(-p.width / 2, p.height / 2);
      ctx.lineTo(p.width / 2, p.height / 2);
      ctx.closePath();
      ctx.fill();

      // Draw Hitbox (Visible Circle)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, HITBOX_RADIUS, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Engine Glow
      ctx.fillStyle = '#60a5fa';
      ctx.globalAlpha = 0.5 + Math.sin(frameCountRef.current * 0.2) * 0.3;
      ctx.fillRect(-2, p.height / 2, 4, 10);
      ctx.restore();

      // Draw Player Bullets
      ctx.fillStyle = '#60a5fa';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#60a5fa';
      bulletsRef.current.forEach((b) => {
        ctx.fillRect(b.x, b.y, b.width, b.height);
      });
      ctx.shadowBlur = 0;

      // Draw Enemies
      enemiesRef.current.forEach((e) => {
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.fillStyle = e.type === 'boss' ? '#f59e0b' : '#ef4444';
        
        if (e.type === 'boss') {
          // Boss Shape
          ctx.beginPath();
          ctx.arc(0, 0, e.width / 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 4;
          ctx.stroke();
          // Eye
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(0, 0, 15, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#000000';
          ctx.beginPath();
          ctx.arc(Math.cos(frameCountRef.current * 0.05) * 5, Math.sin(frameCountRef.current * 0.05) * 5, 5, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // Normal Enemy Shape
          ctx.beginPath();
          ctx.moveTo(0, e.height / 2);
          ctx.lineTo(-e.width / 2, -e.height / 2);
          ctx.lineTo(e.width / 2, -e.height / 2);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      });

      // Draw Enemy Bullets
      enemyBulletsRef.current.forEach((b) => {
        ctx.fillStyle = '#ff4444';
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.width / 2, 0, Math.PI * 2);
        ctx.fill();
        // Glow
        ctx.globalAlpha = 0.3;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.width, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      });

      // Draw Particles
      particlesRef.current.forEach((part) => {
        ctx.globalAlpha = part.life;
        ctx.fillStyle = part.color;
        ctx.fillRect(part.x, part.y, part.width, part.height);
      });
      ctx.globalAlpha = 1.0;
    }

    requestRef.current = requestAnimationFrame(() => {
      update();
      draw();
    });
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(draw);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, health]);

  const startGame = () => {
    setScore(0);
    setHealth(100);
    setDefeatedCount(0);
    setBossHealth(0);
    enemiesRef.current = [];
    bulletsRef.current = [];
    enemyBulletsRef.current = [];
    particlesRef.current = [];
    playerRef.current = {
      x: CANVAS_WIDTH / 2,
      y: CANVAS_HEIGHT - 100,
      width: PLAYER_SIZE,
      height: PLAYER_SIZE,
    };
    setGameState('playing');
  };

  useEffect(() => {
    if (score > highScore) setHighScore(score);
  }, [score]);

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans flex flex-col items-center justify-center p-4 overflow-hidden cursor-none">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-900/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-red-900/10 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 w-full max-w-[800px]">
        {/* HUD */}
        <div className="flex justify-between items-end mb-4 px-2">
          <div className="space-y-1">
            <div className="text-[10px] uppercase tracking-[0.2em] text-blue-400 font-semibold">Hull Integrity</div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-red-500" />
                <div className="w-48 h-2 bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-gradient-to-r from-red-600 to-red-400"
                    initial={{ width: '100%' }}
                    animate={{ width: `${health}%` }}
                  />
                </div>
              </div>
              <div className="text-sm font-mono">{health}%</div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-[10px] uppercase tracking-[0.2em] text-blue-400 font-semibold">Mission Score</div>
            <div className="text-3xl font-mono tracking-tighter">{score.toLocaleString()}</div>
          </div>
        </div>

        {/* Boss Health Bar */}
        <AnimatePresence>
          {bossHealth > 0 && enemiesRef.current.some(e => e.type === 'boss') && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-20 left-1/2 -translate-x-1/2 w-full max-w-md z-20 px-4"
            >
              <div className="text-center mb-1">
                <span className="text-[10px] uppercase tracking-[0.4em] text-orange-500 font-bold">NEBULA OVERLORD</span>
              </div>
              <div className="h-3 bg-black/60 border border-orange-500/30 rounded-full overflow-hidden backdrop-blur-sm">
                <motion.div 
                  className="h-full bg-gradient-to-r from-orange-600 to-yellow-400"
                  initial={{ width: '100%' }}
                  animate={{ width: `${(bossHealth / BOSS_HEALTH_MAX) * 100}%` }}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Game Canvas Container */}
        <div className="relative border border-white/5 rounded-2xl overflow-hidden bg-black shadow-2xl shadow-blue-900/10">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="w-full h-auto block"
          />

          {/* Overlays */}
          <AnimatePresence>
            {gameState === 'menu' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 backdrop-blur-md"
              >
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-center space-y-12"
                >
                  <div className="space-y-4">
                    <h1 className="text-7xl font-bold tracking-tighter italic uppercase bg-clip-text text-transparent bg-gradient-to-b from-white to-blue-500">Nebula Strike</h1>
                    <div className="flex items-center justify-center gap-4">
                      <div className="h-[1px] w-12 bg-blue-500/50" />
                      <p className="text-blue-400 text-xs tracking-[0.5em] uppercase">Bullet Hell Protocol</p>
                      <div className="h-[1px] w-12 bg-blue-500/50" />
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-6">
                    <button
                      onClick={startGame}
                      className="group relative px-16 py-5 bg-blue-600 hover:bg-blue-500 transition-all rounded-full flex items-center gap-4 overflow-hidden shadow-lg shadow-blue-600/20"
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                      <Target className="w-6 h-6" />
                      <span className="font-bold uppercase tracking-[0.2em] text-lg">Engage</span>
                    </button>
                    
                    <div className="grid grid-cols-2 gap-8 text-[10px] text-white/40 uppercase tracking-widest">
                      <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-blue-500" /> Mouse to Move</div>
                      <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-orange-500" /> Auto-Fire Active</div>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            )}

            {gameState === 'gameover' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-red-950/60 backdrop-blur-xl"
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center space-y-8 p-16 rounded-[40px] border border-red-500/20 bg-black/80 shadow-2xl"
                >
                  <div className="space-y-2">
                    <h2 className="text-6xl font-bold tracking-tighter uppercase text-red-500">Vessel Lost</h2>
                    <p className="text-white/40 text-xs tracking-[0.4em] uppercase">Sector Overrun by Hostiles</p>
                  </div>

                  <div className="flex gap-12 justify-center py-8 border-y border-white/5">
                    <div className="text-center">
                      <div className="text-[10px] text-white/30 uppercase tracking-widest mb-2">Final Score</div>
                      <div className="text-4xl font-mono font-bold tracking-tighter">{score.toLocaleString()}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-white/30 uppercase tracking-widest mb-2">Best Record</div>
                      <div className="text-4xl font-mono font-bold tracking-tighter text-blue-400">{highScore.toLocaleString()}</div>
                    </div>
                  </div>

                  <button
                    onClick={startGame}
                    className="w-full py-5 bg-white text-black hover:bg-blue-500 hover:text-white transition-all rounded-2xl flex items-center justify-center gap-4 font-bold uppercase tracking-[0.2em] shadow-xl"
                  >
                    <RotateCcw className="w-6 h-6" />
                    Re-Engage
                  </button>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Info */}
        <div className="mt-8 flex justify-between items-center text-[10px] text-white/20 uppercase tracking-[0.4em]">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2"><Shield className="w-3 h-3 text-blue-500/50" /> Deflector: Online</span>
            <span className="flex items-center gap-2"><Zap className="w-3 h-3 text-orange-500/50" /> Reactor: Critical</span>
          </div>
          <div className="font-mono">Enemies Defeated: {defeatedCount}/3</div>
        </div>
      </div>
    </div>
  );
}
